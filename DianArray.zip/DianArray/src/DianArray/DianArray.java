/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 package DianArray;
 
/**
 *
 * @author DNS
 */
public class DianArray {
    
    public static void main(String[] args) {
        String [] ortu = {"Agus Kariadai", "Asya Ramadhani"};
        String [] anak = {"Albar","DNS"};
        String [] nenek = {"Ira", "Rohmat"};
        String [][] saudara_jauh = {
            {"Anuna","0854-2514-3791"},
            {"Eliza","0859-7691-8931"},
            {"Rada","0819-7325-64129"},
            {"Fara","0825-7433-8552"},
            {"Rehan","0898-7649-8213"}};
        int jumkel = ortu.length+anak.length+nenek.length+saudara_jauh.length;
        
        System.out.println("Namaku Adalah "+anak[1]);
        System.out.println("Saya "+anak.length+" Bersaudara");
        
        System.out.println("");
        for (int i = 0;i<anak.length;i++){
            if ("DNS".equals(anak [i])){
                System.out.println("Saya adalah anak ke-"+(i+1));
        }
    }
        
        System.out.println("");
        System.out.println("Nama Orang Tua Saya Adalah : ");
        for (String ortu1 : ortu) {
            System.out.println(ortu1);
        }
        
        System.out.println("");
        System.out.println("Anak-Anaknya Bernama :");
        for (String anak1 : anak) {
            System.out.println(anak1);
        }
        
        System.out.println("");
        System.out.println("Saudara Jauh Saya Adalah :");
        for (String[] saudara_jauh1 : saudara_jauh) {
            System.out.print(saudara_jauh1[0]);
            System.out.println("   No Teleponnya : " + saudara_jauh1[1]);
        }
        
        System.out.println("");
        System.out.println("Nenek dan Kakek Saya Bernama :");
        
        System.out.println("");
        System.out.println("Jadi Jumlah Anggota Keluarga Saya Adalah "+jumkel);
        
        System.out.println("");
    }
}
    
